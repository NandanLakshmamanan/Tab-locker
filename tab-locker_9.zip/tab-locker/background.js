// ─── State ────────────────────────────────────────────────────────────────────
// tabId → { url, locked, reverting, expiresAt (ms epoch | null), totalSecs, timerId }
const lockedTabs = new Map();

// ─── Badge helpers ────────────────────────────────────────────────────────────
function setLockedBadge(tabId) {
  chrome.action.setBadgeText({ tabId, text: "🔒" });
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#cc0000" });
}
function clearBadge(tabId) {
  chrome.action.setBadgeText({ tabId, text: "" });
}

// ─── Revert URL helper ────────────────────────────────────────────────────────
function revertTab(tabId, url) {
  const info = lockedTabs.get(tabId);
  if (!info) return;
  info.reverting = true;
  chrome.tabs.update(tabId, { url, active: true }, () => {
    setTimeout(() => {
      if (lockedTabs.has(tabId)) lockedTabs.get(tabId).reverting = false;
    }, 1500);
  });
}

// ─── Unlock ───────────────────────────────────────────────────────────────────
function unlockTab(tabId, playSound = false) {
  const info = lockedTabs.get(tabId);
  if (info && info.timerId) clearTimeout(info.timerId);
  lockedTabs.delete(tabId);
  clearBadge(tabId);
  if (playSound) {
    chrome.runtime.sendMessage({ type: "TIMER_DONE" }).catch(() => {});
  }
}

// ─── Get the single locked tab (if any) ──────────────────────────────────────
function getAnyLockedTab() {
  for (const [tabId, info] of lockedTabs.entries()) {
    if (info.locked) return { tabId, info };
  }
  return null;
}

// ─── Content script — blocks links, forms, keyboard shortcuts ─────────────────
function injectBlocker(tabId) {
  chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: () => {
      if (window.__tabLockerInjected) return;
      window.__tabLockerInjected = true;

      document.addEventListener("click", (e) => {
        const anchor = e.target.closest("a");
        if (anchor && anchor.href && !anchor.href.startsWith("javascript:")) {
          e.preventDefault();
          e.stopImmediatePropagation();
        }
      }, true);

      document.addEventListener("submit", (e) => {
        e.preventDefault();
        e.stopImmediatePropagation();
      }, true);

      document.addEventListener("keydown", (e) => {
        const ctrl = e.ctrlKey || e.metaKey;
        // Block tab switching
        if (ctrl && e.key === "Tab") { e.preventDefault(); e.stopImmediatePropagation(); return; }
        // Block new tab, new window, close tab
        if (ctrl && ["w", "t", "n"].includes(e.key.toLowerCase())) { e.preventDefault(); e.stopImmediatePropagation(); return; }
        // Block Ctrl+F4
        if (e.key === "F4" && ctrl) { e.preventDefault(); e.stopImmediatePropagation(); return; }
        // Block back/forward
        if (e.altKey && (e.key === "ArrowLeft" || e.key === "ArrowRight")) { e.preventDefault(); e.stopImmediatePropagation(); return; }
        // Block Enter on links
        if (e.key === "Enter") {
          const anchor = document.activeElement?.closest("a");
          if (anchor?.href) { e.preventDefault(); e.stopImmediatePropagation(); }
        }
      }, true);
    }
  }).catch(() => {});
}

// ─── Build status for popup ───────────────────────────────────────────────────
function buildStatus(tab) {
  const info = lockedTabs.get(tab.id);
  return {
    locked:    !!(info && info.locked),
    url:       info ? info.url : tab.url,
    expiresAt: info ? info.expiresAt : null,
    totalSecs: info ? info.totalSecs : null,
  };
}

// ─── Messages from popup ──────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "GET_STATUS") {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return sendResponse({ locked: false, url: "", expiresAt: null, totalSecs: null });
      sendResponse(buildStatus(tab));
    });
    return true;
  }

  if (msg.type === "TOGGLE_LOCK") {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab || !tab.id) return;
      const tabId = tab.id;
      const info  = lockedTabs.get(tabId);

      if (info && info.locked) {
        unlockTab(tabId);
        sendResponse({ locked: false, url: tab.url, expiresAt: null, totalSecs: null });
      } else {
        const totalSecs = msg.durationSecs || (msg.durationMins ? msg.durationMins * 60 : 0);
        const expiresAt = totalSecs > 0 ? Date.now() + totalSecs * 1000 : null;
        const timerId   = expiresAt ? setTimeout(() => unlockTab(tabId, true), totalSecs * 1000) : null;

        lockedTabs.set(tabId, { url: tab.url, locked: true, reverting: false, expiresAt, totalSecs, timerId });
        setLockedBadge(tabId);
        injectBlocker(tabId);
        sendResponse({ locked: true, url: tab.url, expiresAt, totalSecs });
      }
    });
    return true;
  }
});

// ─── 1. Block URL changes via webNavigation ───────────────────────────────────
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  const info = lockedTabs.get(details.tabId);
  if (!info || !info.locked || info.reverting) return;
  if (details.url === info.url) return;
  revertTab(details.tabId, info.url);
});

// ─── 2. Belt-and-suspenders: tabs.onUpdated ───────────────────────────────────
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  const info = lockedTabs.get(tabId);
  if (!info || !info.locked || info.reverting) return;
  if (changeInfo.status === "complete") injectBlocker(tabId);
  if (!changeInfo.url || changeInfo.url === info.url) return;
  revertTab(tabId, info.url);
});

// ─── 3. Block new tabs while locked ──────────────────────────────────────────
chrome.tabs.onCreated.addListener((newTab) => {
  const locked = getAnyLockedTab();
  if (!locked) return;

  // Give it a tiny moment to fully create, then close it and refocus
  setTimeout(() => {
    chrome.tabs.remove(newTab.id, () => {
      // Refocus the locked tab
      chrome.tabs.update(locked.tabId, { active: true });
      // Also focus its window
      chrome.tabs.get(locked.tabId, (t) => {
        if (!chrome.runtime.lastError) {
          chrome.windows.update(t.windowId, { focused: true });
        }
      });
    });
  }, 50);
});

// ─── 4. Block new windows while locked ───────────────────────────────────────
chrome.windows.onCreated.addListener((newWindow) => {
  const locked = getAnyLockedTab();
  if (!locked) return;

  // Close the new window immediately
  setTimeout(() => {
    chrome.windows.remove(newWindow.id, () => {
      // Refocus the locked tab's window
      chrome.tabs.get(locked.tabId, (t) => {
        if (!chrome.runtime.lastError) {
          chrome.windows.update(t.windowId, { focused: true });
          chrome.tabs.update(locked.tabId, { active: true });
        }
      });
    });
  }, 50);
});

// ─── 5. Focus heartbeat — 100ms check locked tab is always active ─────────────
function enforceFocus() {
  if (lockedTabs.size === 0) return;
  for (const [lockedTabId, info] of lockedTabs.entries()) {
    if (!info.locked) continue;
    chrome.tabs.get(lockedTabId, (lockedTab) => {
      if (chrome.runtime.lastError) { lockedTabs.delete(lockedTabId); return; }
      if (!lockedTab.active) {
        chrome.tabs.update(lockedTabId, { active: true });
        chrome.windows.update(lockedTab.windowId, { focused: true });
      }
    });
  }
}

setInterval(enforceFocus, 100);

chrome.tabs.onActivated.addListener(() => {
  enforceFocus();
  setTimeout(enforceFocus, 30);
  setTimeout(enforceFocus, 80);
  setTimeout(enforceFocus, 200);
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  enforceFocus();
  setTimeout(enforceFocus, 50);
  setTimeout(enforceFocus, 150);
});

// ─── 6. Block tab close — reopen if closed while locked ──────────────────────
chrome.tabs.onRemoved.addListener((tabId) => {
  const info = lockedTabs.get(tabId);
  if (!info || !info.locked) return;
  if (info.timerId) clearTimeout(info.timerId);

  chrome.tabs.create({ url: info.url, active: true }, (newTab) => {
    lockedTabs.delete(tabId);
    lockedTabs.set(newTab.id, {
      url: info.url, locked: true, reverting: false,
      expiresAt: info.expiresAt, totalSecs: info.totalSecs,
      timerId: info.expiresAt
        ? setTimeout(() => unlockTab(newTab.id, true), Math.max(0, info.expiresAt - Date.now()))
        : null
    });
    setLockedBadge(newTab.id);
    chrome.tabs.onUpdated.addListener(function waitForLoad(tid, changeInfo) {
      if (tid !== newTab.id || changeInfo.status !== "complete") return;
      chrome.tabs.onUpdated.removeListener(waitForLoad);
      injectBlocker(newTab.id);
    });
  });
});

// ─── 7. Ctrl+Shift+Q shortcut ────────────────────────────────────────────────
chrome.commands.onCommand.addListener((command) => {
  if (command !== "toggle-timer-lock") return;

  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab || !tab.id) return;
    const tabId = tab.id;
    const info  = lockedTabs.get(tabId);

    if (info && info.locked) {
      const timerActive = info.expiresAt && Date.now() < info.expiresAt;
      if (timerActive) return;
      unlockTab(tabId);
    } else {
      const totalSecs = 25 * 60;
      const expiresAt = Date.now() + totalSecs * 1000;
      const timerId   = setTimeout(() => unlockTab(tabId, true), totalSecs * 1000);
      lockedTabs.set(tabId, { url: tab.url, locked: true, reverting: false, expiresAt, totalSecs, timerId });
      setLockedBadge(tabId);
      injectBlocker(tabId);
    }
  });
});
