const dot           = document.getElementById("dot");
const statusText    = document.getElementById("status-text");
const urlDisplay    = document.getElementById("url-display");
const toggleBtn     = document.getElementById("toggle-btn");
const minsInput     = document.getElementById("mins-input");
const secsInput     = document.getElementById("secs-input");
const inputRow      = document.getElementById("input-row");
const presetsRow    = document.getElementById("presets-row");
const countdownWrap = document.getElementById("countdown-wrap");
const countdownText = document.getElementById("countdown-text");
const countdownLbl  = document.getElementById("countdown-label");
const ring          = document.getElementById("ring");

const CIRCUMFERENCE = 213.6; // 2π × 34
let tickInterval = null;

// ── Play completion sound (Web Audio API — no file needed) ────────────────────
function playDoneSound() {
  try {
    const ctx = new AudioContext();

    // Three ascending pleasant tones
    const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
    notes.forEach((freq, i) => {
      const osc  = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.18);

      gain.gain.setValueAtTime(0, ctx.currentTime + i * 0.18);
      gain.gain.linearRampToValueAtTime(0.35, ctx.currentTime + i * 0.18 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.18 + 0.45);

      osc.start(ctx.currentTime + i * 0.18);
      osc.stop(ctx.currentTime  + i * 0.18 + 0.5);
    });
  } catch (e) {
    // AudioContext blocked — silent fallback
  }
}

// ── Listen for TIMER_DONE from background ─────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "TIMER_DONE") {
    playDoneSound();
    timerDoneUI();
  }
});

// ── Preset chips ──────────────────────────────────────────────────────────────
document.querySelectorAll(".chip").forEach(chip => {
  chip.addEventListener("click", () => {
    minsInput.value = chip.dataset.mins;
    secsInput.value = "00";
  });
});

// ── Clamp seconds input ───────────────────────────────────────────────────────
secsInput.addEventListener("change", () => {
  let v = parseInt(secsInput.value, 10);
  if (isNaN(v) || v < 0) v = 0;
  if (v > 59) v = 59;
  secsInput.value = String(v).padStart(2, "0");
});

// ── Timer done UI state ───────────────────────────────────────────────────────
function timerDoneUI() {
  stopTick();
  toggleBtn.disabled        = false;
  countdownText.textContent = "00:00";
  countdownLbl.textContent  = "✅ Timer done — tap to unlock";
  ring.style.stroke         = "#44cc66";
  ring.style.strokeDashoffset = 0;
}

// ── Render UI ─────────────────────────────────────────────────────────────────
function renderUI(locked, url, expiresAt, totalSecs) {
  urlDisplay.textContent = url || "—";

  if (locked) {
    dot.className          = "status-dot locked";
    statusText.textContent = "Tab is LOCKED";
    toggleBtn.textContent  = "🔓 Unlock This Tab";
    toggleBtn.className    = "main-btn unlock-btn";

    inputRow.style.display   = "none";
    presetsRow.style.display = "none";
    countdownWrap.classList.add("visible");

    if (expiresAt && totalSecs) {
      const msLeft = expiresAt - Date.now();
      if (msLeft <= 0) {
        // Already expired (popup opened late)
        timerDoneUI();
      } else {
        startTick(expiresAt, totalSecs);
      }
    } else {
      // No timer — unlock available immediately
      toggleBtn.disabled        = false;
      countdownText.textContent = "∞";
      countdownLbl.textContent  = "no timer — unlock anytime";
      ring.style.strokeDashoffset = CIRCUMFERENCE;
    }

  } else {
    dot.className          = "status-dot unlocked";
    statusText.textContent = "Tab is unlocked";
    toggleBtn.textContent  = "🔒 Lock This Tab";
    toggleBtn.className    = "main-btn lock-btn";
    toggleBtn.disabled     = false;

    inputRow.style.display   = "";
    presetsRow.style.display = "";
    countdownWrap.classList.remove("visible");
    ring.style.stroke = "#cc2222"; // reset ring colour

    stopTick();
  }
}

// ── Countdown ticker ──────────────────────────────────────────────────────────
function startTick(expiresAt, totalSecs) {
  stopTick();
  tick(expiresAt, totalSecs);
  tickInterval = setInterval(() => tick(expiresAt, totalSecs), 500);
}

function stopTick() {
  if (tickInterval) { clearInterval(tickInterval); tickInterval = null; }
}

function tick(expiresAt, totalSecs) {
  const msLeft   = Math.max(0, expiresAt - Date.now());
  const secsLeft = Math.ceil(msLeft / 1000);
  const mins     = String(Math.floor(secsLeft / 60)).padStart(2, "0");
  const secs     = String(secsLeft % 60).padStart(2, "0");

  countdownText.textContent = `${mins}:${secs}`;

  // Ring drains clockwise as time passes
  const fraction = Math.min(1, secsLeft / totalSecs);
  ring.style.strokeDashoffset = CIRCUMFERENCE * (1 - fraction);

  if (secsLeft <= 0) {
    timerDoneUI();
    // Sound is triggered by TIMER_DONE message from background
    // but if popup was open the whole time, fire it here too just in case
    playDoneSound();
  } else {
    toggleBtn.disabled       = true;
    countdownLbl.textContent = "🔒 Unlock blocked until timer ends";
  }
}

// ── Toggle button ─────────────────────────────────────────────────────────────
toggleBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "GET_STATUS" }, (res) => {
    if (!res) return;

    if (res.locked) {
      chrome.runtime.sendMessage({ type: "TOGGLE_LOCK" }, (r) => {
        if (r) renderUI(r.locked, r.url, r.expiresAt, r.totalSecs);
      });
    } else {
      const mins         = parseInt(minsInput.value, 10) || 0;
      const secs         = parseInt(secsInput.value, 10) || 0;
      const durationSecs = mins * 60 + secs;

      chrome.runtime.sendMessage(
        { type: "TOGGLE_LOCK", durationSecs },
        (r) => { if (r) renderUI(r.locked, r.url, r.expiresAt, r.totalSecs); }
      );
    }
  });
});

// ── Load on open ──────────────────────────────────────────────────────────────
chrome.runtime.sendMessage({ type: "GET_STATUS" }, (res) => {
  if (res) renderUI(res.locked, res.url, res.expiresAt, res.totalSecs);
});
